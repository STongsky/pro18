<footer class="footer">
      <div class="container">

        <span class="text-muted">
            <div class="white">
        
            © 2017-2018 Doujin KZN | Site Keep by Doujin KZN.
            <br>
            Please share us on
            <br>
            </div>
              <div class="row">
 <div class ="col-lg-3 col-md-3 col-sm-3 col-xs-3"></div>    
 
 <div class ="col-lg-3 col-md-3 col-sm-3 col-xs-3">      
           <!-- <div class="tweet"> -->
           <div>
              <!-- <a href="https://twitter.com/share?ref_src=twsrc%5Etfw" id="tweet"class="twitter-share-button" data-size="large" data-url="https://doujintradetest.000webhostapp.com" data-show-count="false">Tweet</a> 
                -->
                 <input type ="button" style="width:80px; background-image: url('image/tweet.PNG')"; class="twitter-share-button" id="tweet" name="tweetbutton" onclick="window.open('https://twitter.com/share?ref_src=twsrc%5Etfw');"></button> 
                
            </div>
</div>

<script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>


<!-- 將這個標記放在標頭中，或放在內文結尾標記前面。 -->

<script src="https://apis.google.com/js/platform.js" async defer>
  {lang: 'en-GB'}
</script>

 <div class ="col-lg-3 col-md-3 col-sm-3 col-xs-3">  
<!-- 在您要顯示「分享按鈕」的位置放上這個標記。 -->

<div>
<!--<a class="g-plus" href="https://plus.google.com/share?url=https://doujintradetest.000webhostapp.com" onclick="javascript:window.open(this.href,
  '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');
  return false;"> -->
    
     <input type ="button" style="width:70px; background-image: url('../image/gplusshare.png')"; class="g-plus" id="g-plus" name="g-plusbutton" onclick="window.open('https://plus.google.com/share?url=https://doujintradetest.000webhostapp.com');"></button> 
    
    <!--<img src="../image/gplusshare.png" alt="Share on Google+"/> -->
  </a>
</div>
<br>





 <div class ="col-lg-3 col-md-3 col-sm-3 col-xs-3"></div> 
</div>    
            </span>
<br>
      </div>
    </footer>
</div>
