<?php
include 'session.php';
include 'header.php';

?>



 
                    
            <div class="row">
                <div class="col-md-3"> </div>
                <div class="col-md-6 form-box">
                    <div class="form-top">
                        <div class="form-top-left">
                          
                        
                        </div>

                    </div>
                    
                                                 <div class="panel panel-default">
                                 <div class="panel-body">
                                       <h3>Success to register</h3>
                   
            	</div>
</div></div>
                <div class="col-md-3"> </div>
            </div>
        </div>
        

    <?php include 'footer.php'?>
</body>
</html>