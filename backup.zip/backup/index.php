<?php

require_once('session.php');
require_once('header.php');


//print_r($_SESSION);
//exit;
?>

<div id="eg2">
    <?php include 'male.php'?>
</div>
<p>

<div id="eg2">
    <?php include 'female.php'?>
</div>

<p>

<div id="eg2">
    <?php include 'r18.php'?>
</div>


<br><br><br><br><br><br>
    <?php include 'footer.php'?>
</body>
</html>
