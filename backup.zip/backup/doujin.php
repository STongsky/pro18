<?php
require_once('session.php');
require_once('header.php');
?>

<?php
$upload_user = $_SESSION['user'];
?>
      <tr>
<div class="container">
  <div class="row">
    <div id="eg2" class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
        <br>
        
        <h1>What is Doujin?</h1>
        
        <br>	


<h3>"Doujin" refer to a group of people share the same thinking or same theme to produce and publish the works or books according to Daijirin 2<sup>nd</sup>edition.</h3>
<br>
<h3>Nowadays, "Doujin" refer to a person or a organization publishing the creations with his own name which is not the commercial event but share the interest and which "Doujin" creations always sell in the "Doujin" event for example,<a href="http://www.doujin-cp.com">Creative Paradise</a>, <a href="http://www.rainbow-gala.com/main.html">Rainbow Gala</a>, <a href="http://www.cwhk.org/">CWHK</a>, <a href="http://www.comicworld.com.tw/Acts/hk">CWTHK<a> are the popular "Doujin" events in Hong Kong. </h3>
<hr>
        <h1>The etiquette of "Doujin" event</h1>
<br>
<h3>
    <ul>
        <li><strong>Do not cut in line.</strong> Even you have some friends wanted to join you.</li>
        <br>
        <li><strong>Take photo with the cosplayers with their permission</strong> and do not block the passageway</li>
        <br>
        <li><strong>Do not bargin the price</strong> in the "Doujin" events, since "Doujin" creators work so hard on the "Doujin" creations!</li>
    </ul>
</h3>
                    <br><br><br><br><br>
        </div>
              </tr>

 <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12 order-lg-first
      order-md-first order-sm-first" >
      <tr>
        <?php include 'book_update.php'?>
      </tr>
    </div>
    
      
  </div>
</div>

<br><br><br><br><br><br>
    <?php include 'footer.php'?>
</body>
</html>